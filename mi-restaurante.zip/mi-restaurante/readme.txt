_Hacer la conexion con mongod
_Ejecutar el comando npm i
_Ejecutar node app
_Ejecutar npm start y aceptar otro puerto